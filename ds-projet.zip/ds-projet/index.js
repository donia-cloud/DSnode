require('./db');
const express = require('express');
const seance_router=require('./Routing/seances');
const film_router=require('./Routing/films');
const port=process.env.PORT||3000
const app=express();
app.use(express.json());

app.use('/api/seance',seance_router);
app.use('/api/film',film_router);
app.listen(port,()=> console.log('Server on '+port+'....'))