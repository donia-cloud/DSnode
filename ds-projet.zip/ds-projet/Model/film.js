const mongoose=require("mongoose")
const joi=require('joi')

const flimSchema=new mongoose.Schema({
    name:{type:String,require:true},
    acteur:{type:[String],validate : { validator:function (v){
        return v.length > 0}, message : "A acteur must be have exist"}},
    seance:{
        id : { type : mongoose.Schema.Types.ObjectId, ref: 'seance'}
        , name : String 
    }
});

let film_validation_schema={
    name:joi.string().required(),
    seance:{
        id :joi.string(),
        name:joi.string()


    },
    acteur:joi.array().items(joi.string())
}
let film_update_schema={
    acteur:joi.array().items(joi.string()),
    seance:{
        id:joi.string(),
        name:joi.string()
    }
}
function validation_film(body){
    return joi.validate(body,film_validation_schema);
}
function validaion_update(body){
    return joi.validate(body,film_update_schema);
}

const Film=mongoose.model("film",flimSchema);
module.exports.film=Film;
module.exports.validation_film=validation_film;
module.exports.validaion_update=validaion_update;