const mongoose=require("mongoose");
const joi=require('joi');

const SeanceSchema=new mongoose.Schema({
    date:{type:Date,required:true},
    temps:{type:Number,min:0,max:4},
    place:{type:Number ,min:0,max:120}
});

let seance_validate_schema={
     date:joi.date().required(),
     temps:joi.number().min(0).max(4),
     place:joi.number().min(0).max(120)
}
let seance_update_schema={
    temps:joi.number().min(0).max(4),
    place:joi.number().min(0).max(120)

}

function seance_validate(body){
    return joi.validate(body,seance_validate_schema);
}
function seance_update(body){
    return joi.validate(body,seance_update_schema);
}
const Seance =mongoose.model('Seance',SeanceSchema);

module.exports.Seance=Seance;
module.exports.seance_validate= seance_validate;
module.exports.seance_update= seance_update;