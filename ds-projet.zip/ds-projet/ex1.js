/* 1 console.log("a");

call1(function(){
    6 console.log("b");
    call2(function(){
        4 console.log("c");
        call3(function(){
          3  console.log("d");
        });
       5 console.log("e");
    });
    7 console.log("f");

});
2 console.log("g");
/*--------------------------------------------------------------------------------------*/
console.log("a");
function call1(){
    return new Promise((resolve,reject)=>{
            setTimeout(()=>{
                console.log("b")
                resolve(call2)
                console.log("f")

            })
    });
}
function call2(){
    return new Promise((resolve,reject)=>{
            setTimeout(()=>{
                console.log("c")
                resolve(call3)
                console.log("e")

            })
    });
}
function call3(){
    
                console.log("d")            
    
}
console.log("g");
call1().then(data=>{call2(data)}).then(call3());
/*--------------------------------------------------------------------------*/
console.log("---------------------------------------")
console.log("a")
async function processData(){
    var data=await call1(call2);
    data =await call2(call3);
    data=call3();
}
console.log("g")
processData()