const { model } = require("mongoose");
const {Seance,seance_validate,seance_update}=require("../Model/seance");
const router=require('express').Router();
const _=require('lodash');
   
router.get('',async(req,res)=>{
    res.send(await Seance.find());
  });
  router.get('/:id',async (req,res) => {
    let seance = await Seance.findById(req.params.id)                          
    res.send(seance);
});

router.post('',async(req,res)=>{
    
    let valid=seance_validate(req.body);
    if(valid.error)
    return res.status(400).send(validation.error.details[0].message);

    let seance=new Seance(_.pick(req.body,'date','temps','place'));
    try{
         seance=await seance.save()
    }
    catch(error){
        res.status(400).send("Save in DB Error"+ error.message);
    }
    res.send(seance)
});


router.put('/:id',async(req,res)=>{
   let validation = seance_update(req.body);
    
    if(validation.error)
        return res.status(400).send(validation.error.details[0].message);

    let seance = await Seance.findById(req.params.id)
    seance = _.merge(seannce,req.body);
    seance = await seance.save();
    res.send(seance);
});

router.delete('/:id',async (req,res) => {
    let seance = await Seance.findById(req.params.id)
    await Seance.deleteOne({_id: req.params.id})
    res.send(seance);
});
router.put('/reservation:id',async(req,res)=>{
    let nbr = req.body.nombrereservation ; 
    let seance = await Seance.findById(req.params.id)
    if (seance.place < nbr ) { 
        return res.status(400).send('le nombre de classe ne suffie pas votre reservation ');
      
    }
    seance.place = seance.place -nbr ; 
    seance = await seance.save();
    res.send(seance);
});

module.exports=router;